
#pragma config  FOSC    = INTRC_NOCLKOUT
#pragma config  WDTE    = OFF
#pragma config  PWRTE   = OFF
#pragma config  MCLRE   = OFF
#pragma config  CP      = OFF
#pragma config  CPD     = OFF
#pragma config  BOREN   = OFF
#pragma config  IESO    = OFF
#pragma config  FCMEN   = OFF
#pragma config  LVP     = OFF

#pragma config  BOR4V   = BOR40V
#pragma config  WRT     = OFF

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
#include <xc.h>
#include "i2c.h"
#include <pic16f887.h> // Aseg�rate de que est�s utilizando la cabecera correcta
#include "LCD.h"

#include <stdlib.h>
#include <stdio.h>
//*****************************************************************************
// Definici�n de variables
//*****************************************************************************
// Declaraci�n de variables globales
unsigned char receivedData = 0; //Aqu� se almacenar� el dato recibido del esclavo1
unsigned char receivedData2 = 0; //Aqu� se almacenar� el dato recibido del esclavo2
//unsigned char receivedData3 = 0; //Aqu� se almacenar� el dato recibido del esclavo3

//-----------------------TEMPERATURA--------------------------------------------
char tempStr[4];
float temperaturaC;
int rawValue;
uint16_t raw_temp;




#define MOTOR_PIN RC0 // Ejemplo, el pin RC0 controla el motor
#define SENSOR_NIVEL RC1 // Ejemplo, el pin RB0 controla el sensor de nivel
unsigned char SENSOR_TEMP;  //Aqu� se almacenar� el dato recibido del esclavo3
#define _XTAL_FREQ  8000000

//*****************************************************************************
// Funci�n principal
//*****************************************************************************

void setup(void)
{
    ANSEL = 0;
    ANSELH = 0;
    
    TRISD = 0;
    
    TRISCbits.TRISC0 = 0; // Pin RC0 (MOTOR) como salida
    TRISCbits.TRISC1 = 0; // Pin RC0 (MOTOR) como salida

    OSCCONbits.IRCF = 0b111; //8 MHz
    OSCCONbits.SCS = 1;
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE1bits.RCIE = 1;
    PIR1bits.RCIF = 0;
    //initUART(8);
    I2C_Master_Init(100000);        // Inicializar Comuncaci�n I2C
}

void main(void) {
    setup();
    Lcd_Init();
    
    while(1) {
        // Communication with the first slave
        I2C_Master_Start();
        I2C_Master_Write(0x31); // Address of the second slave 0x31
        receivedData = I2C_Master_Read(0);
        // Perform read or write operations with the second slave
        //---------------------------MOTOR DC-------------------------------------------
        
        if (receivedData == 1) {
            MOTOR_PIN = 1; // Enciende el motor
//            Lcd_Clear();
//            Lcd_Set_Cursor(1, 1);
//            Lcd_Write_String("Motor encendido");
        }
        else{
            MOTOR_PIN = 0; // Desactiva la bandera
//            Lcd_Clear();
//            Lcd_Set_Cursor(1, 1);
//            Lcd_Write_String("Motor apagado");
        } 
         
        I2C_Master_Stop();
        __delay_ms(200);
//---------------------------------segundo----------------------------------------        

        // Communication with the second slave
        I2C_Master_Start();
        I2C_Master_Write(0x53); // Address of the second slave  0x33
        receivedData2 = I2C_Master_Read(0); //se piden m�s datos
        // Perform read or write operations with the second slave
        //---------------------------sensor nivel-------------------------------------------
        
        if (receivedData2 == 1) {
            SENSOR_NIVEL = 1; // Enciende la bandera
            MOTOR_PIN = 0; // Desactiva la bandera
//            Lcd_Clear();
//            Lcd_Set_Cursor(2, 1);
//            Lcd_Write_String("Necesita agua");
        }
        else{
            SENSOR_NIVEL = 0; // Desactiva la bandera
//            Lcd_Clear();
//            Lcd_Set_Cursor(2, 1);
//            Lcd_Write_String("Todo ok");
        } 
        //__delay_ms(1000); // Espera 1 segundo antes de la siguiente lectura 
        I2C_Master_Stop();      
        //__delay_ms(200);
////---------------------------------tercero----------------------------------------        
//
//        // Communication with the second slave
//        I2C_Master_Start();
//        I2C_Master_Write(0x83); // Address of the second slave  0x33
//        SENSOR_TEMP = I2C_Master_Read(0); //se piden m�s datos
//        // Perform read or write operations with the second slave
//        //---------------------------sensor temperatura-------------------------------------------
        
//        Lcd_Clear();
//        Lcd_Set_Cursor(1, 1);
//        Lcd_Write_String("Temp:");
//        // Limpieza de la LCD y mostrar el valor de temperatura
//        Lcd_Clear();
//        Lcd_Set_Cursor(1, 1);
//        Lcd_Write_String("Temp:");
//        Lcd_Set_Cursor(2, 1);
//        sprintf(tempStr, "%.1uC", SENSOR_TEMP);
//        Lcd_Write_String(tempStr);  
        //__delay_ms(1000); // Espera 1 segundo antes de la siguiente lectura 
//        I2C_Master_Stop();      
        __delay_ms(200);        

       
        
    }
    
}
