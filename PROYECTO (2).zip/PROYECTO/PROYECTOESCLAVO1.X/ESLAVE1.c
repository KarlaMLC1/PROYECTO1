#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
#include "i2c.h"
//#include "ADC.h"
#include <xc.h>
//*****************************************************************************
// Definici�n de variables
//*****************************************************************************

#define _XTAL_FREQ  8000000
uint8_t z;
uint8_t temp;
unsigned char motorFlag = 0; // Inicialmente, la bandera est� desactivada
#define MOTOR_PIN RC0 // Ejemplo, el pin RC0 controla el motor


void __interrupt() isr(void){
   if(PIR1bits.SSPIF == 1){ 
        SSPCONbits.CKP = 0;
        if ((SSPCONbits.SSPOV) || (SSPCONbits.WCOL)){
            z = SSPBUF;                 // Read the previous value to clear the buffer
            SSPCONbits.SSPOV = 0;       // Clear the overflow flag
            SSPCONbits.WCOL = 0;        // Clear the collision bit
            SSPCONbits.CKP = 1;         // Enables SCL (Clock)
        }
        if(!SSPSTATbits.D_nA && !SSPSTATbits.R_nW) {
            //__delay_us(7);
            z = SSPBUF;                 // Lectura del SSBUF para limpiar el buffer y la bandera BF
            //__delay_us(2);
            PIR1bits.SSPIF = 0;         // Limpia bandera de interrupci�n recepci�n/transmisi�n SSP
            SSPCONbits.CKP = 1;         // Habilita entrada de pulsos de reloj SCL
            while(!SSPSTATbits.BF);     // Esperar a que la recepci�n se complete
            motorFlag = SSPBUF;             // Guardar en el PORTB el valor del buffer de recepci�n
            __delay_us(250);
            temp = SSPBUF;
            
        }else if(!SSPSTATbits.D_nA && SSPSTATbits.R_nW){
            z = SSPBUF;                 //Envio de la varialbe POT al MASTER
            BF = 0;                     
            SSPBUF = motorFlag;
            SSPCONbits.CKP = 1;
            __delay_us(250);
            while(SSPSTATbits.BF);
        }
        PIR1bits.SSPIF = 0;    
    }
}


void setup(void){
    //oscilador a 8M Hz
    //OSCILLATOR(1);
    
    ANSEL =  0;
    ANSELH = 0x00;
    //TRISB = 0x00;
    TRISD = 0xFF;
    //PORTB = 0x00;
    OSCCONbits.IRCF = 0b111; //8 MHz
    OSCCONbits.SCS = 1;
    I2C_Slave_Init(0x30);   
}

void Timer1_Init() {
    T1CON = 0b00000001; // TMR1ON = 1 (habilitar TMR1), T1CKPS = 00 (preescalador 1:1)
    TMR1H = 0x00; // Reiniciar el registro alto del temporizador
    TMR1L = 0x00; // Reiniciar el registro bajo del temporizador
}

unsigned int Timer1_Read() {
    return (TMR1H << 8) | TMR1L; // Leer el valor del temporizador
}

void main() {
    setup();

    TRISCbits.TRISC2 = 0; // Pin RC2 (Trigger) como salida
    TRISCbits.TRISC1 = 1; // Pin RC1 (Echo) como entrada
    TRISCbits.TRISC0 = 0; // Pin RC1 (Echo) como entrada
    
    Timer1_Init(); // Inicializar el temporizador TMR1

    while(1) {
        // Generar pulso de 10us en el pin Trigger (RC2)
        PORTCbits.RC2 = 1;
        __delay_us(10);
        PORTCbits.RC2 = 0;

        // Esperar hasta que el pin Echo (RC1) se active
        while (!PORTCbits.RC1);

        // Medir el tiempo que el pin Echo (RC1) permanece en alto
        TMR1 = 0;
        while (PORTCbits.RC1);
        unsigned int time = Timer1_Read(); // Leer el valor del temporizador
        
        // Calcular la distancia en cent�metros
        double distance = (time * 0.0343) / 2;
        
        // Encender el LED en el Puerto D si la distancia es menor a 10 cm
        if (distance < 25) {
            //PORTB = 0b11111111; // Mantener el LED encendido
            motorFlag = 1; // Enciende el motor
            MOTOR_PIN = 1;
        } else {
            //PORTB = 0; // Apagar el LED
            motorFlag = 0; // Apaga el motor
            MOTOR_PIN = 0;
        }
        
        __delay_ms(500); // Esperar un tiempo antes de la siguiente medici�n
    }
}