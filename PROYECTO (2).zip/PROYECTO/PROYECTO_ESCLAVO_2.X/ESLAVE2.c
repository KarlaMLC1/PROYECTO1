#pragma config FOSC = INTRC_NOCLKOUT// Oscillator Selection bits (RCIO oscillator: I/O function on RA6/OSC2/CLKOUT pin, RC on RA7/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled and can be enabled by SWDTEN bit of the WDTCON register)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = OFF      // RE3/MCLR pin function select bit (RE3/MCLR pin function is digital input, MCLR internally tied to VDD)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Reset Selection bits (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal/External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)
#pragma config LVP = OFF        // Low Voltage Programming Enable bit (RB3 pin has digital I/O, HV on MCLR must be used for programming)

// CONFIG2
#pragma config BOR4V = BOR40V   // Brown-out Reset Selection bit (Brown-out Reset set to 4.0V)
#pragma config WRT = OFF        // Flash Program Memory Self Write Enable bits (Write protection off)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
#include "i2c.h"
//#include "ADC.h"
#include <xc.h>
//*****************************************************************************
// Definici�n de variables
//*****************************************************************************

#define _XTAL_FREQ  8000000
uint8_t z;
uint8_t temp;
volatile unsigned int cwStepCount = 0;
volatile unsigned int ccwStepCount = 0;
const unsigned int maxStepsPerRoutine = 200;  // Cambia este valor seg�n necesites
unsigned char nivFlag = 0; // Inicialmente, la bandera est� desactivada

// Definici�n de pines para el motor y el driver ULN2003
#define MotorPin1 PORTDbits.RD0
#define MotorPin2 PORTDbits.RD1
#define MotorPin3 PORTDbits.RD2
#define MotorPin4 PORTDbits.RD3


// Funci�n para realizar un paso del motor en sentido horario
void stepCW() {
    MotorPin1 = 1;
    MotorPin2 = 1;
    MotorPin3 = 1;
    MotorPin4 = 0;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 0;
    MotorPin2 = 1;
    MotorPin3 = 1;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 1;
    MotorPin2 = 0;
    MotorPin3 = 1;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 1;
    MotorPin2 = 1;
    MotorPin3 = 0;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
}

void stepCCW() {
    MotorPin1 = 1;
    MotorPin2 = 1;
    MotorPin3 = 0;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 1;
    MotorPin2 = 0;
    MotorPin3 = 1;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 0;
    MotorPin2 = 1;
    MotorPin3 = 1;
    MotorPin4 = 1;
    __delay_ms(5);  // Pausa para el movimiento
    MotorPin1 = 1;
    MotorPin2 = 1;
    MotorPin3 = 1;
    MotorPin4 = 0;
    __delay_ms(5);  // Pausa para el movimiento
}


void __interrupt() isr(void){
       
   if(PIR1bits.SSPIF == 1){ 
        SSPCONbits.CKP = 0;
        if ((SSPCONbits.SSPOV) || (SSPCONbits.WCOL)){
            z = SSPBUF;                 // Read the previous value to clear the buffer
            SSPCONbits.SSPOV = 0;       // Clear the overflow flag
            SSPCONbits.WCOL = 0;        // Clear the collision bit
            SSPCONbits.CKP = 1;         // Enables SCL (Clock)
        }
        if(!SSPSTATbits.D_nA && !SSPSTATbits.R_nW) {
            //__delay_us(7);
            z = SSPBUF;                 // Lectura del SSBUF para limpiar el buffer y la bandera BF
            //__delay_us(2);
            PIR1bits.SSPIF = 0;         // Limpia bandera de interrupci�n recepci�n/transmisi�n SSP
            SSPCONbits.CKP = 1;         // Habilita entrada de pulsos de reloj SCL
            while(!SSPSTATbits.BF);     // Esperar a que la recepci�n se complete
            __delay_us(250);
            
        }else if(!SSPSTATbits.D_nA && SSPSTATbits.R_nW){
            z = SSPBUF;                 //Envio de la varialbe POT al MASTER
            BF = 0;                     
            SSPBUF = nivFlag;
            SSPCONbits.CKP = 1;
            __delay_us(250);
            while(SSPSTATbits.BF);
        }
        PIR1bits.SSPIF = 0;    
    }
}

void setup(void){
    //oscilador a 8M Hz
    //OSCILLATOR(1);
    
    PORTB = 0x00;
    PORTD = 0x00;
    PORTE = 0x00;
    
    // Configuraci�n de pines como salidas
    TRISD = 0x00;  // Configura todos los pines de PORTD como salidas
    TRISB = 0x00;
    TRISE = 0x00;

    TRISAbits.TRISA0 = 1;  // Puerto A, Pin 0 como entrada anal�gica (sensor de nivel de agua)
    I2C_Slave_Init(0x52);   
    ANS0 = 1;    // Habilita la funci�n de entrada anal�gica en el pin
    OSCCONbits.IRCF = 0b111; //8 MHz
    OSCCONbits.SCS = 1;
    
}


void main(void) {
        
     setup();
    // Configuraci�n del oscilador interno a 8MHz
    OSCCONbits.IRCF = 0b111;  // Frecuencia del oscilador interno a 8MHz
    
    // Bucle principal
    while(1) {
        if (cwStepCount < maxStepsPerRoutine) {
            stepCW();  // Girar en sentido horario
            //__delay_ms(5);  // Pausa entre pasos
            cwStepCount++;
        } else if (ccwStepCount < maxStepsPerRoutine) {
            stepCCW();  // Girar en sentido antihorario
            //__delay_ms(5);  // Pausa entre pasos
            ccwStepCount++;
        } else {
            // Resetea los contadores y cambia de rutina
            cwStepCount = 0;
            ccwStepCount = 0;
        }
        // Configuraci�n del ADC
        ADCON0 = 0b00000001; // Seleccionar AN0 como entrada y habilitar el m�dulo ADC
        ADCON1 = 0b00000000; // Referencia de voltaje VDD y VSS
        // Inicializaci�n
        PORTB = 0;   // Apagar ambos LEDs al inicio
    
        // Iniciar la conversi�n ADC
        ADCON0bits.GO = 1;
        
        // Esperar a que la conversi�n ADC termine
        while (ADCON0bits.GO);
        
        // Leer el valor convertido
        uint16_t adcValue = (ADRESH << 8) + ADRESL;
        
        if (adcValue < 25) {
            // Nivel bajo de agua: encender los LEDs
            PORTB=0b11111111;
            nivFlag = 1; // Enciende el motor
        } else {
            // Nivel alto de agua: apagar los LEDs
            PORTB=0;
            nivFlag = 0; // Enciende el motor

        }
        
    }
    
    return;
}