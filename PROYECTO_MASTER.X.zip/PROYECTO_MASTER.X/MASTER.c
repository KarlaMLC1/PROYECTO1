
#pragma config  FOSC    = INTRC_NOCLKOUT
#pragma config  WDTE    = OFF
#pragma config  PWRTE   = OFF
#pragma config  MCLRE   = OFF
#pragma config  CP      = OFF
#pragma config  CPD     = OFF
#pragma config  BOREN   = OFF
#pragma config  IESO    = OFF
#pragma config  FCMEN   = OFF
#pragma config  LVP     = OFF

#pragma config  BOR4V   = BOR40V
#pragma config  WRT     = OFF

//*****************************************************************************
// Definici�n e importaci�n de librer�as
//*****************************************************************************
#include <stdint.h>
#include <xc.h>
#include "i2c.h"
#include <pic.h> // Aseg�rate de que est�s utilizando la cabecera correcta

//*****************************************************************************
// Definici�n de variables
//*****************************************************************************
// Declaraci�n de variables globales
unsigned char receivedData = 0; //Aqu� se almacenar� el dato recibido del esclavo1
unsigned char receivedData2 = 0; //Aqu� se almacenar� el dato recibido del esclavo2
#define MOTOR_PIN RC0 // Ejemplo, el pin RC0 controla el motor
#define SENSOR_NIVEL RD0 // Ejemplo, el pin RC0 controla el motor
#define _XTAL_FREQ  8000000

//*****************************************************************************
// Funci�n principal
//*****************************************************************************
void main(void) {
    TRISD = 0x00;
    //TRISB = 0x00;
    PORTB = 0x00;
    //TRISE = 0x00;
    //PORTE = 0x00;    
    PORTD = 0x00;
    TRISCbits.TRISC0 = 0; // Pin RC1 (MOTOR) como salida
    // Initialization code for I2C and other peripherals if needed
    I2C_Master_Init(100000);

    while(1) {
        __delay_ms(200);
        // Communication with the first slave
        I2C_Master_Start();
        I2C_Master_Write(0b00110001); // Address of the second slave 0x31
        receivedData2 = I2C_Master_Read(0);
        // Perform read or write operations with the second slave
        I2C_Master_Stop();
//---------------------------------segundo----------------------------------------        
        __delay_ms(200);
        // Communication with the second slave
        I2C_Master_Start();
        I2C_Master_Write(0b00110011); // Address of the second slave  0x33
        receivedData = I2C_Master_Read(0); //se piden m�s datos
        // Perform read or write operations with the second slave
        I2C_Master_Stop();      
        __delay_ms(200);
//---------------------------MOTOR DC-------------------------------------------
        
        if (receivedData == 1) {
            MOTOR_PIN = 1; // Enciende el motor
        }
        else{
            MOTOR_PIN = 0; // Desactiva la bandera
        } 
         
//---------------------------sensor nivel-------------------------------------------
        
        if (receivedData2 == 1) {
            SENSOR_NIVEL = 1; // Enciende la bandera
        }
        else{
            SENSOR_NIVEL = 0; // Desactiva la bandera
        } 
        __delay_ms(1000); // Espera 1 segundo antes de la siguiente lectura        
        
    }
    
}





